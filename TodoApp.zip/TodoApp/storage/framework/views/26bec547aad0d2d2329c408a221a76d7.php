
<?php $__env->startSection('main'); ?>
    <div class="main">
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MyworkSpace\Laravel\TodoApp\resources\views/todo/day.blade.php ENDPATH**/ ?>