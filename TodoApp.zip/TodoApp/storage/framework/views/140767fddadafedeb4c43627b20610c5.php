
<?php $__env->startSection('main'); ?>
    <div class="main text-center ">
        <a  href="<?php echo e(route('new')); ?>" class="btn btn-primary m-3">Ajouter<a>
        <div class="main text-center">
            <h4 class="text-center m-3">Mes tâches</h4>
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($task->termine == true): ?>
                    <div class="task col-lg-10">
                        <div class="task_info">
                            <h5> <?php echo e($task->titre); ?> </h5>
                            <p> <?php echo e($task->description); ?> </p>
                        </div>
                        <div class="datetime">
                            <h5>Debut : <?php echo e($task->debut); ?> </h5>
                            <h5>Fin : <?php echo e($task->fin); ?> </h5>
                            <h5>Date : <?php echo e($task->jour); ?> </h5>
                        </div>
                        <div class="du">
                            <a href="<?php echo e(route('edittask', $task->id)); ?>" class="btn btn-primary">Modifier</a>
                            <a href="<?php echo e(route('endtask', $task->id)); ?>" class="btn btn-success">Non terminé</a>
                            <form action="<?php echo e(route('deletetask', $task->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"class="btn btn-danger">Supprimer</button>
                            </form>
                        </div>
                        
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\MyworkSpace\Laravel\TodoApp\resources\views/todo/endtask.blade.php ENDPATH**/ ?>